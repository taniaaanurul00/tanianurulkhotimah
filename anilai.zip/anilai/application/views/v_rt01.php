
					
<div id="page-wrapper">
			<div class="main-page">
				<h1><center>DAFTAR PELANGGARAN</center></h1>
				</div>
				
				<div class="row">
					
					<div class="row calender widget-shadow">
						<table class="table stats-table ">
							<thead>
								<th>Nama </th>
								<th>NIK</th>
								<th>Tempat & Tanggal Lahir</th>
								<th>Uisa</th>
								<th>Jenis Kelamin</th>
								<th>Gol.Darah</th>
								<th>Status Perkawinan</th>
								<th>Aksi</th>
								
									<?php $no = 1;
									foreach ($rt01 as $key): ?>
									<tr >
										<td><?php echo $key->nama ?></th>
										<td><?php echo $key->NIK ?></td>
										<td><?php echo $key->ttl ?></td>
										<td><?php echo $key->usia ?></td>
										<td><?php echo $key->jk ?></th>
										<td><?php echo $key->goldar ?></td>
										<td><?php echo $key->status ?></td>
										<td><span class="label label-warning">Edit</span> | <span class="label label-danger">Delete</span></td>
										
									</tr>
									<?php endforeach ?>
								
							</thead>
							<tbody>
								
							</tbody>
						</table>
					</div>
		</div>
	</div>
