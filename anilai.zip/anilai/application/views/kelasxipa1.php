<h1><font color= "#000000" width="1000" height="600" >Data Mel</font></h1><hr>
    
    <font size="5">ID Balita   : 320 </font><br>
    <font size="5">Nama Balita : Mel</font><br>
    <font size="5">Nama Ibu    : Leni</font><br>
    <font size="5">Alamat      : Jambi</font><br>
    <hr>