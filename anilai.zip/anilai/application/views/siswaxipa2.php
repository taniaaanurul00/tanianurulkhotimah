<body>

<div class="container" style="margin-top: 20px">
<div class="col-md-12">
<h2 style="text-align: center;margin-bottom: 30px"> Data Siswa Kelas X IPA 2 </h2>
<table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
<thead>
  <tr>
    <th>ID Siswa</th>
    <th>NIS</th>
    <th>Nama Siswa</th>
    <th>Jenis Kelamin</th>
    <th>Tempat Lahir</th>
    <th>Tanggal Lahir</th>
    <th>Alamat</th>
    <th>No Telp Siswa</th>
    <th>Nama Ayah</th>
    <th>Nama Ibu</th>
    <th>No Telp Orang Tua</th>
  </tr>
</thead>
<tbody>
  <?php
  $no = 100201;
  foreach ($data_siswa as $siswa) {
  ?>
  <tr>
    <td><?php echo $no++;?></td>
    <td><?php echo $siswa->nis;?></td>
    <td><?php echo $siswa->nama_siswa;?></td>
    <td><?php echo $siswa->jk;?></td>
    <td><?php echo $siswa->tempat_lahir;?></td>
    <td><?php echo $siswa->tanggal_lahir;?></td>
    <td><?php echo $siswa->alamat;?></td>
    <td><?php echo $siswa->notelp_siswa;?></td>
    <td><?php echo $siswa->nama_ayah;?></td>
    <td><?php echo $siswa->nama_ibu;?></td>
    <td><?php echo $siswa->notelp_orangtua;?></td>
    
  </tr>
<?php } ?>

</tbody>
</table>
</div>
</div>













  <script type ="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
  <script type ="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script type ="text/javascript" src="https://cdn.datatables.net/1.10..16/js/jquery.dataTables.min.js"></script>
  <script type ="text/javascript" src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
  <script type="text/javascript">
    $(document).ready( function () {
    $('#table_id').DataTable();
  } );
</script>
</body>





        