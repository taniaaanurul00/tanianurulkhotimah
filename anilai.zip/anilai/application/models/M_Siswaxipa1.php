<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class M_Siswaxipa1 extends CI_Model {

	public function tampil_siswaxipa1()
	{
			$query = $this->db->order_by('id_siswa','DESC')->get('tbl_siswaxipa1');


			return $query->result();
	}
}

?>