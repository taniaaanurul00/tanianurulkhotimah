<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class M_Dashboard extends CI_Model {

	public function tampil_kelas()
	{
			$query = $this->db->order_by('id_kelas','DESC')->get('tbl_kelas');


			return $query->result();
	}
}

?>