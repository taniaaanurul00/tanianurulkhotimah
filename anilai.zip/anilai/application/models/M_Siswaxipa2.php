<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class M_Siswaxipa2 extends CI_Model {

	public function tampil_siswaxipa2()
	{
			$query = $this->db->order_by('id_siswaxipa2','DESC')->get('tbl_siswaxipa2');


			return $query->result();
	}
}

?>