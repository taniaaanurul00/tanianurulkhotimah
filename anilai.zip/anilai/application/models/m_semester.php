<?php

class m_semester extends CI_Model{

	public function get_data(){
		return $this->db->query("select * from semester")->result();
	}
}