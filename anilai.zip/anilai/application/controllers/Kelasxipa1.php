<?php

class Kelasxipa1 extends CI_Controller {

  public function index()
  {
    
    $this->load->view('templates/header');
    $this->load->view('templates/sidebar');
    $this->load->view('kelasxipa1');
    $this->load->view('templates/footer');

  
  }
}