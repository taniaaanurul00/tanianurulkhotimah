<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Siswaxipa2 extends CI_Controller {

		public function __construct ()
		{
			parent ::__construct ();
			$this->load->model('m_siswaxipa2');//panngil model
		}


	public function index()
	{
		$data = array(
				'title'		=>'Data Siswa',
				'data_siswa' => $this->m_siswaxipa2->tampil_siswaxipa2()
		);

		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('siswaxipa2',$data);
		$this->load->view('templates/footer');

	
	}
}