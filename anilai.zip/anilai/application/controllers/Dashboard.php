<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

		public function __construct ()
		{
			parent ::__construct ();
			$this->load->model('m_dashboard');//panngil model
		}


	public function index()
	{
		$data = array(
				'title'		=>'Data Kelas',
				'data_kelas' => $this->m_dashboard->tampil_kelas()
		);

		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('dashboard',$data);
		$this->load->view('templates/footer');

	
	}
}