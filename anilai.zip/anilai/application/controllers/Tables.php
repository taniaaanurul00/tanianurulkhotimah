<?php

class Tables extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->->model('m_semester');
	}

  public function index()
  {
  	$data = array(
  		'daftar' => $this->m_semester->get_data() ,
  	);
    
    $this->load->view('templates/header');
    $this->load->view('templates/sidebar');
    $this->load->view('tables', $data);
    $this->load->view('templates/footer');

  
  }
}