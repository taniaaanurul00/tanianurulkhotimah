<?php

class Utilities extends CI_Controller {

  public function index()
  {
    
    $this->load->view('templates/header');
    $this->load->view('templates/sidebar');
    $this->load->view('utilities');
    $this->load->view('templates/footer');

  
  }
}