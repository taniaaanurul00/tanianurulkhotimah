<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Siswaxipa1 extends CI_Controller {

		public function __construct ()
		{
			parent ::__construct ();
			$this->load->model('m_siswaxipa1');//panngil model
		}


	public function index()
	{
		$data = array(
				'title'		=>'Data Siswa',
				'data_siswa' => $this->m_siswaxipa1->tampil_siswaxipa1()
		);

		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('siswaxipa1',$data);
		$this->load->view('templates/footer');

	
	}
}